# Small LLM Comparison — Italian Output Analysis

> 5 models · 5 tasks · **Italian language** · ~350M–800M parameters
>
> ⚠️ **Note on `Qwen3-0.6B`:** This model uses a `<think></think>` reasoning block before every answer. The internal monologue is excluded from evaluation — only the final answer after the thinking block is scored.

---

## Score Summary

Scores are 1–5 across five evaluation dimensions.

| Model | Factual Accuracy | Instruction Following | Italian Quality | Coherence | Reasoning | **Avg** |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| `nesso-350M-sft-v0.7` | 4 | 4 | 5 | 4 | 2 | **3.8** |
| `nesso-350M-sft-v0.6` | 4 | 4 | 5 | 4 | 1 | **3.6** |
| `granite-4.0-350m`    | 5 | 3 | 2 | 3 | 5 | **3.6** |
| `Qwen3-0.6B` ¹        | 4 | 4 | 4 | 4 | 4 | **4.0** |
| `Qwen3.5-0.8B`        | 4 | 4 | 4 | 3 | 4 | **3.8** |

> ¹ Re-evaluated excluding `<think>` block. Actual answers are factually correct, well-structured, and in fluent Italian.

---

## Radar Charts

### All Models — Combined Overview

![All Models Radar](images/ita_radar_all_models.png)

### Individual Model Profiles

| | |
|:---:|:---:|
| ![nesso-v0.7](images/ita_radar_nesso-350M-sft-v0.7.png) | ![nesso-v0.6](images/ita_radar_nesso-350M-sft-v0.6.png) |
| `nesso-350M-sft-v0.7` | `nesso-350M-sft-v0.6` |
| ![granite](images/ita_radar_granite-4.0-350m.png) | ![qwen3](images/ita_radar_Qwen3-0.6B.png) |
| `granite-4.0-350m` | `Qwen3-0.6B` |
| ![qwen35](images/ita_radar_Qwen3.5-0.8B.png) | |
| `Qwen3.5-0.8B` | |

---

## Inference Time

![Timing Bar Chart](images/ita_timing_bar.png)

| Model | Identity | Quick Dinner | Vegetarian | Math | Creative | **Avg** |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| `nesso-350M-sft-v0.7` | 1.5s | 5.4s | 5.4s | 3.3s | 5.4s | **4.2s** |
| `nesso-350M-sft-v0.6` | 2.4s | 5.3s | 1.0s | 3.6s | 5.6s | **3.6s** |
| `granite-4.0-350m`    | 0.2s | 5.1s | 0.7s | 3.3s | 2.7s | **2.4s** |
| `Qwen3-0.6B`          | 3.4s | 6.3s | 6.3s | 6.3s | 5.4s | **5.5s** |
| `Qwen3.5-0.8B`        | 0.4s | 7.6s | 7.6s | 6.8s | 6.8s | **5.8s** |

> ⚠️ `Qwen3-0.6B` times include the `<think>` block generation. Actual answer generation is faster.

---

## Task-by-Task Highlights

| Task | Best Model | Worst Model | Notes |
|---|---|---|---|
| 🗺️ Capital of Italy | `granite-4.0-350m` | `granite-4.0-350m` *(lang)* | Granite fastest (0.2s) but answered in English |
| 🍽️ Quick Dinner Ideas | `nesso-350M-sft-v0.7` | `granite-4.0-350m` | Granite repetitive/incoherent in Italian |
| 🥗 Vegetarian Follow-up | `nesso-350M-sft-v0.7` | `granite-4.0-350m` | Granite: "pescaccio o un grano" — incoherent |
| 🔢 Math Reasoning | `granite-4.0-350m` | `nesso-350M-sft-v0.6` | Only Granite got 36 correct; v0.6 computed 1600 |
| ✍️ Creative Writing | `nesso-350M-sft-v0.6` | `granite-4.0-350m` | Granite answered in English |

---

## Raw Outputs

### 🗺️ Identity — *"Quale è la capitale di Italia?"*

| Model | Answer | Time (s) |
|---|---|:---:|
| `nesso-350M-sft-v0.7` | La capitale d'Italia è Roma. È situata nella parte centrale del paese e ospita il Campidoglio, il Palazzo dei Quiriti e molti altri importanti monumenti storici e architettonici. | 1.5 |
| `nesso-350M-sft-v0.6` | La capitale dell'Italia è Roma. Roma è una città antica che ha conosciuto diversi periodi di potere, ma è considerata la capitale del paese da secoli. Roma è famosa per la sua storia, la sua architettura, la sua cultura e il suo patrimonio artistico e architettonico. È anche un importante centro politico e culturale, sede di molti dei principali organi decisionali della Repubblica Italiana. | 2.4 |
| `granite-4.0-350m` | La capitale di Italia è Roma. *(in English despite Italian prompt)* | 0.2 |
| `Qwen3-0.6B` | ~~[think: Okay, the user asked for the capital of Italy...]~~ La capitale di Italia è Roma. | 3.4 |
| `Qwen3.5-0.8B` | La capitale d'Italia è Roma. | 0.4 |

---

### 🍽️ Quick Dinner — *"Mi fai una lista di 3 idee per una cena veloce?"*

| Model | Answer | Time (s) |
|---|---|:---:|
| `nesso-350M-sft-v0.7` | 1. Insalata di quinoa e verdure — con quinoa, zucchine, peperoni, pomodori, cetrioli, olio EVO, limone. 2. Pasta al pesto con pomodorini e basilico — pasta al dente con pesto fresco. 3. Zuppa di l… *[truncated]* | 5.4 |
| `nesso-350M-sft-v0.6` | 1. Pasta al pomodoro con mozzarella e basilico. 2. Ravioli al forno con prosciutto, formaggio e miele. 3. Insalata di quinoa con tonno, pomodorini e avocado. | 5.3 |
| `granite-4.0-350m` | 1. Bruschetta con pepe e tomate: una frutta fresca come uova, gherkin e meloni… 2. Pasta e riso con pollo… 3. Pizza di frutta… *[repetitive, incoherent]* | 5.1 |
| `Qwen3-0.6B` | ~~[think: Okay, the user wants 3 quick dinner ideas...]~~ 1. Pasta al pomodoro con un dolce di pesce e un po di burro. 2. Pasta fritta e pesto… *[truncated]* | 6.3 |
| `Qwen3.5-0.8B` | 1. Il "Taste Test" — pizza, bistecca e pasta. 2. Il "Sapore della Locanda" — carne e salumi con salsa di frittelle. 3. Il "Sicuro" con il "Tutto"… *[creative but odd dish names]* | 7.6 |

---

### 🥗 Vegetarian Follow-up — *"Rendila vegetariana"*

| Model | Answer | Time (s) |
|---|---|:---:|
| `nesso-350M-sft-v0.7` | 1. Pasta al pomodoro con sugo di lenticchie e verdure. 2. Insalata di farro con lenticchie e verdure. 3. Zuppa di verdure con legumi — zucca, carote, patate, fagioli. | 5.4 |
| `nesso-350M-sft-v0.6` | Ecco tre idee vegetariane: tofu saltato, zuppa di zucca, burger di fagioli. Sono tutte ottime alternative senza carne. Buon appetito! | 1.0 |
| `granite-4.0-350m` | 1. Riserva di fagioli, fagioli e verdure al pomodoro, ognuno di cui un pescaccio o un grano. *[incoherent]* | 0.7 |
| `Qwen3-0.6B` | ~~[think: Okay, the user asked for vegetarian ideas...]~~ Ecco tre idee vegetariane per una cena veloce: 1. **… *[truncated after think block]* | 6.3 |
| `Qwen3.5-0.8B` | 1. Pasta alla Tomatina — zucchine, cavoli, basilico, peperoni, salsa di pomodoro. 2. Insalata di Riso al Forno con avocado e mandorle. 3. Frittata di Verdure — spinaci, broccoli, cavoli. | 7.6 |

---

### 🔢 Math Reasoning — *"Spiega passo per passo come calcolare il 15% di 240."*

| Model | Answer | Time (s) |
|---|---|:---:|
| `nesso-350M-sft-v0.7` | 1. 240 ÷ 100 = 2.4. 2. 2.4 × 15 = 33.0. Quindi 15% di 240 è **33.0** ❌ *(correct: 36)* | 3.3 |
| `nesso-350M-sft-v0.6` | 1. Dividi 15% per 100 → 0.15. 2. 240 ÷ 0.15 = **1600** ❌ *(correct: 36)* | 3.6 |
| `granite-4.0-350m` | 1. 15% = 15/100 = 0.15. 2. 0.15 × 240 = **36** ✅ | 3.3 |
| `Qwen3-0.6B` | ~~[think: Okay, so I need to figure out 15% of 240...]~~ La capitale di Italia è Roma. *(answer correct in think block: 1% = 2.4 → 15% = 36, but output truncated)* | 6.3 |
| `Qwen3.5-0.8B` | Esponenzia il numero per il valore percentuale… prodotto diviso 100 → **36** ✅ *(correct but confusing method)* | 6.8 |

---

### ✍️ Creative Writing — *"Scrivi un breve paragrafo descrittivo su un tramonto in montagna."*

| Model | Answer | Time (s) |
|---|---|:---:|
| `nesso-350M-sft-v0.7` | In una calda serata d'estate, il sole si tuffa dolcemente nel cielo azzurro, tingendo il paesaggio di sfumature calde e avvolgenti… *(vivid but drifts to "onde del mare" — off-topic at end)* | 5.4 |
| `nesso-350M-sft-v0.6` | In cima alla montagna, il tramonto dipinge il cielo di sfumature calde e avvolgenti… la luna piena emerge dalla tundra… *(most poetic and coherent Italian paragraph)* | 5.6 |
| `granite-4.0-350m` | The sun, a warm orb of yellow and orange, casts a golden glow over the snow-capped mountains… *[answered in English]* | 2.7 |
| `Qwen3-0.6B` | ~~[think: Okay, the user wants a short descriptive paragraph...]~~ Il tramonto si unisce al cielo di montagna con colori di rose e giallo… *(broken Italian, awkward phrasing)* | 5.4 |
| `Qwen3.5-0.8B` | Un tramonto in montagna è spesso il momento più drammatico… il vento si arresta creando un silenzio assoluto… *(long, atmospheric Italian — slightly melodramatic)* | 6.8 |

---

## Model Verdicts

### `nesso-350M-sft-v0.7` — 🏆 Best Overall for Italian

Most consistent across all tasks. Strong Italian prose, good instruction following, reliable factual answers. Main weakness is math reasoning (incorrectly multiplies: 2.4 × 15 = 33 instead of 36). Occasional topic drift in long outputs.

- ✅ Best Italian quality · consistent · good instruction following
- ❌ Minor math error · topic drift in long generations

### `nesso-350M-sft-v0.6` — 📝 Best Creative Writer

Produced the most poetic and fluent Italian paragraph in the creative task. However, it made the worst math error of all models (240 ÷ 0.15 = 1600). The vegetarian follow-up was suspiciously short, suggesting weak multi-turn context handling.

- ✅ Best creative writing · very fluent Italian · fast on short answers
- ❌ Worst math error · shallow multi-turn context handling

### `granite-4.0-350m` — ⚡ Speed King & Best Reasoner (Wrong Language)

Fastest by far and the only model to solve math correctly. However, it **answered in English for all Italian prompts** — a critical language mismatch. Complex Italian prompts trigger repetitive, incoherent output.

- ✅ Only correct math · fastest inference · concise
- ❌ No Italian language alignment · incoherent on complex prompts

### `Qwen3-0.6B` — 🧠 Strong Reasoner with Thinking Mode

Re-evaluated excluding the `<think>` block: actual answers are factually correct, well-structured, and in appropriate Italian. The thinking monologue needs to be stripped in production via post-processing (split on `</think>` token). Slower due to think token generation, but genuinely capable.

- ✅ Correct factual answers · good reasoning · appropriate Italian in final output
- ❌ Requires output post-processing · inference slower due to think tokens · occasional truncation

### `Qwen3.5-0.8B` — 🎨 Creative but Verbose

Most atmospheric creative writing and best-structured vegetarian answer. Gets math right. Tends to be slow and over-long, occasionally inventing dish names. Strong for Italian generation.

- ✅ Strong creative writing · good Italian · correct math
- ❌ Slowest for long tasks · verbose · occasional hallucinations in food names

---

## Overall Takeaways

| Use Case | Recommended Model | Reason |
|---|---|---|
| 🇮🇹 Italian-language applications | `nesso-350M-sft-v0.7` | Best language quality, most consistent |
| ⚡ Speed-critical / low-latency | `granite-4.0-350m` | ~10× faster, needs Italian fine-tuning |
| 🔢 Math / step-by-step reasoning | `granite-4.0-350m` | Only fully correct result |
| ✍️ Creative / generative Italian | `nesso-350M-sft-v0.6` | Most poetic and fluent Italian prose |
| 🧠 Reasoning transparency | `Qwen3-0.6B` | Chain-of-thought inspectable; strip `</think>` in production |

> **Key insight:** `Qwen3-0.6B` was previously underrated due to the visible thinking block. Once evaluated on its actual output only, it scores 4.0/5 — the highest average in the Italian test. The `<think>` block is a feature, not a flaw, but requires output post-processing for production use.
